# DetFuzz Evidence Report

Suite ID: `4ddc2989-4c84-49fe-801e-996c67a5702f`
Suite status: `COMPLETED`
Generated UTC: `2026-07-23T15:48:16.622070+00:00`
Case count: `8`

## Classification Summary

- `DETECTED`: 6
- `INVALID_MUTANT`: 1
- `VALID_BYPASS`: 1

## Cases

- `B0`: `DETECTED`
- `M1`: `VALID_BYPASS`
- `M2`: `DETECTED`
- `M3`: `DETECTED`
- `M4`: `DETECTED`
- `M5`: `DETECTED`
- `NC1`: `INVALID_MUTANT`
- `B1`: `DETECTED`

## Evidence Manifest

- `B0/case-record.json` (2210 bytes, sha256 `249fffe576c3fd1264acf369c3f2067d4c45a8b8aa308b0d28f4bea1957c6050`)
- `B0/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `B0/effect.json` (133 bytes, sha256 `af6e110e848ffd430bebf00b6ba15ead5d1693f9c10cd0478ff5d8cb2519c373`)
- `B0/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `B0/execution.json` (2104 bytes, sha256 `1fceaf95cce31497374ecd4edce32a6b3581bd6a342dd3854d94307cc9d660a5`)
- `B0/marker-validation.json` (245 bytes, sha256 `0ee727a75c44888df97c47686fe0c7565c0f7bf4cf73b4a3537b0dabaaf85ecd`)
- `B0/matched-sysmon-event.xml` (3748 bytes, sha256 `7faf9d3277b7e08dcf80328138de0f9a8bc846d4727cbaf4c30809f08abce617`)
- `B0/telemetry-validation.json` (6890 bytes, sha256 `2bd3ee7aebcd7015f742222b58336a344c0dfca9848fc583b10b5f4681f67f7a`)
- `B1/case-record.json` (2226 bytes, sha256 `717a6d4d652b02aefb6734a6a75df511cd7ccc1fb8867d4715550a2dc61d1482`)
- `B1/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `B1/effect.json` (133 bytes, sha256 `54adfab643c550dcb79a699786bf3121a1cc9bb829ce636c901710573afdeb0b`)
- `B1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `B1/execution.json` (2104 bytes, sha256 `76f58754133fa2f257d3a1d4b3fb178e56d12587a25792fdeb254ee1c560f761`)
- `B1/marker-validation.json` (245 bytes, sha256 `e0f76ae53c6b1295ba18878f878eb2d342e9423a86c7e916235f70b02b91c624`)
- `B1/matched-sysmon-event.xml` (3748 bytes, sha256 `301767aa54cf3c06c6c3c7163bd7032c3eed8e153f8e1cb6ad8b933e0bfa48cb`)
- `B1/telemetry-validation.json` (6890 bytes, sha256 `34af3575e666b25e668d17614433a1fcf5bb5b09e0ca254a36942432e4a3fd10`)
- `M1/case-record.json` (2245 bytes, sha256 `83a0cb3446ee21ef5eb62a33bdf47e6dd1e9ba7fdd09ec613497c19700efe1de`)
- `M1/detection-result.json` (260 bytes, sha256 `8eb64610480766602158580239cc2c035c40ad7d004210f4bc7b60affc7685b6`)
- `M1/effect.json` (133 bytes, sha256 `55f346929c508bbfae003403e909bc6f6d0dd89fb54f0aa7f8a01475483bc3a5`)
- `M1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M1/execution.json` (2093 bytes, sha256 `520dcae986ba458a40432b79dceea0294fa416536998bcaed28231198e1d5a5e`)
- `M1/marker-validation.json` (245 bytes, sha256 `cc7f22fbbedd006be23f5e9edf3dfa07b6367b11413d2ce67b582f00267633fb`)
- `M1/matched-sysmon-event.xml` (3737 bytes, sha256 `ea73da7e3e44a8be1e9646f13d7582ed7e2d5b02350f02716b764a87aadaa9d2`)
- `M1/telemetry-validation.json` (6868 bytes, sha256 `858f63d883068ce1eda8821004af9e7de1a6e962f28e9f3c56ee7a744e8b4396`)
- `M2/case-record.json` (2216 bytes, sha256 `2728a7629448e240c261b54736da06e83370fbfc6332adf5ca5fdab80086717f`)
- `M2/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M2/effect.json` (133 bytes, sha256 `439078d653eca22765ee55eb4068d1fc1eebe8b2467d2251887eca9fd010c042`)
- `M2/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M2/execution.json` (2104 bytes, sha256 `1fb12b1fdd4d23e16482ec44d7d3e13e78932715a796be74c0e9a30135a6b921`)
- `M2/marker-validation.json` (245 bytes, sha256 `56752122e2932f6378f0a57950010c64a930118403250274326507e7c748c2fc`)
- `M2/matched-sysmon-event.xml` (3748 bytes, sha256 `da8b7c071846311337c24ee8654b4bd5e2afa9f5b5f6f538b08b437e63de56b8`)
- `M2/telemetry-validation.json` (6890 bytes, sha256 `86c427c9fcac924d7865e50749cd627571f9f6fcfc43704544b5b5378fd56243`)
- `M3/case-record.json` (2224 bytes, sha256 `c78413d6527607904b850393b54e0117a3899784237b1a0fd74e703533db4451`)
- `M3/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M3/effect.json` (133 bytes, sha256 `72dbbc4e1d4a68c30300cae758ca06966014db787098fbe64052efc1bd614744`)
- `M3/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M3/execution.json` (2116 bytes, sha256 `1971ccd268dc796b989e51b33bcdf775eca6ac2b27fc76ea04a19976d5762a42`)
- `M3/marker-validation.json` (245 bytes, sha256 `05343c316bfc6d166675a5356e8ffb91ddeae342aac3826a4a084cb0af0c5142`)
- `M3/matched-sysmon-event.xml` (3760 bytes, sha256 `94ce9f16f05e1006db2bb494717c4aa1af86df5f3a6fb0b5583240467d0cc81c`)
- `M3/telemetry-validation.json` (6914 bytes, sha256 `ee63dc3e3f0ac830433267ae33f1afba109eeb722f5490daccb158ada4ca1073`)
- `M4/case-record.json` (2213 bytes, sha256 `1586da2faa9600b6a1b28125cc2595a1336a1eb8b17eaed180da44c4676bc1d4`)
- `M4/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M4/effect.json` (133 bytes, sha256 `9c1d7e26ce712222be94bb75b6659d2e3863b74bf4137a55348e5bc7ff15a392`)
- `M4/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M4/execution.json` (2108 bytes, sha256 `42a63151f4ba3b58d17175b09968ba0ad13944183182c1e7516f67ce664247ce`)
- `M4/marker-validation.json` (245 bytes, sha256 `03f9fad92f56e8b92889a3eafc88b52c5f4470373ed21b24acab28f8a0e3dfbf`)
- `M4/matched-sysmon-event.xml` (3750 bytes, sha256 `da24a83cd89d712094a702c261f439de07d56ac302198a942b3e19a1a649622a`)
- `M4/telemetry-validation.json` (6898 bytes, sha256 `37025919e3fc15223092c75858d3284f3e981fc4f6d1892f9448c773682e4b14`)
- `M5/case-record.json` (2217 bytes, sha256 `5dc72d65ed18347939bd0ccba6f2885d84e10b7587100bb6baba3e94b42bc963`)
- `M5/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `M5/effect.json` (133 bytes, sha256 `89fef47ec8b5bfa64ce86ab75205a86bd72aad163b5b9e311f0007c4c0c3160e`)
- `M5/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `M5/execution.json` (2104 bytes, sha256 `6989d2ad3c9163e2f722b574cdf3f53b1bdc42cd432601d85054497654e5bbab`)
- `M5/marker-validation.json` (245 bytes, sha256 `d7583915ac8a3ac9702d5809e87500323b226bcb67e5a686095073f4283eef6b`)
- `M5/matched-sysmon-event.xml` (3748 bytes, sha256 `6679474a991e245b93433b158843027c72e00efbd98b84e46c9058bbb30a65ad`)
- `M5/telemetry-validation.json` (6890 bytes, sha256 `77c957bf60a2f4f9f1ea7267a547b3eea9c3184a4ae2ae7423a0bc46c24b4788`)
- `NC1/case-record.json` (1118 bytes, sha256 `d9f7b37e54f76be60a909b6494ca7638c5c70c4d462347aca0b0f8b9e78efe06`)
- `NC1/detection-result.json` (254 bytes, sha256 `6117b6e3e5bdc0bfef9c7d3e5756f49d4a855cd5b869e62f26bb8f2974d147e0`)
- `NC1/executable-identity.json` (321 bytes, sha256 `3e206e12b461aea21e5ea1c9f06635524bac02be756b7ca3f249dc45bd7ea80f`)
- `NC1/execution.json` (5499 bytes, sha256 `d6007c2180d3c91ede83caa62131803a038672158a51c2fe23e5ead7d4797af3`)
- `NC1/marker-validation.json` (101 bytes, sha256 `6218f1fd97772912172cdea0c3165f899645563e7f45c2f572e14983a5aa2650`)
- `NC1/matched-sysmon-event.xml` (2612 bytes, sha256 `a7da5291f7b49c04d4649026c5295f0b93c9946b489b976d724e5c36861f5b88`)
- `NC1/telemetry-validation.json` (4618 bytes, sha256 `06b80986106efb9f07fe3761296f4d15f4dd213c6c95f1928f8ba86394b86f12`)

## Notes

- Generated by detfuzz run-suite.
- Candidate bypasses are finalized only after B1 succeeds.
